from django.urls import path
from user import views



urlpatterns = [
    path("kakao/", views.KakaoView.as_view()),
    path("kakao/callback",views.KakaoCallBackView.as_view())


]