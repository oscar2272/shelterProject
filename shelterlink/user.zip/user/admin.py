from django.contrib import admin

from user.models import CustomUsers


admin.site.register(CustomUsers)