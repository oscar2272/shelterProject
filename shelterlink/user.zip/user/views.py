from anaconda_cloud_auth import login
from django.http import HttpResponse
from django.views.generic import View
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import redirect
from rest_framework.response import Response
from rest_framework import status
import requests
from user.models import CustomUsers

class KakaoView(View):
    def get(self, request):
        kakao_api = "https://kauth.kakao.com/oauth/authorize?response_type=code"
        client_id = "f89b2d5a52ca01c3aed278f0c8e870a7"
        redirect_uri = "http://127.0.0.1:8000/user/kakao/callback"

        return HttpResponse(f"{kakao_api}&client_id={client_id}&redirect_uri={redirect_uri}")
        #return redirect(f"{kakao_api}&client_id={client_id}&redirect_uri={redirect_uri}")
  
class KakaoCallBackView(View):
    def get(self, request):
        code = request.GET.get("code")
        print("code:",code)
        data = {
            "grant_type": "authorization_code",
            "client_id": "f89b2d5a52ca01c3aed278f0c8e870a7",
            "redirect_uri": "http://127.0.0.1:8000/user/kakao/callback",
            "code": code
        }
        kakao_token_api = "https://kauth.kakao.com/oauth/token"
        response = requests.post(kakao_token_api, data=data)
        # -----------------------------------------------
        access_token = response.json().get("access_token")
        # -----------------------------------------------
        kakao_user_api = "https://kapi.kakao.com/v2/user/me"
        user_information = requests.get(kakao_user_api, headers={"Authorization": f"Bearer {access_token}"}).json()

        # Kakao API로부터 받은 사용자 정보
        kakao_user_id = user_information.get("id")
        kakao_user_username = user_information.get("properties", {}).get("nickname")

        try :
            user = CustomUsers.objects.get(user_id = kakao_user_id)
            login(request,user)
            return Response(status=status.HTTP_200_OK)
        except CustomUsers.DoesNotExist:
            user = CustomUsers.objects.create_user(                    
                    username=kakao_user_username,
                )
            user.save()
            login(request,user)
            return Response(status=status.HTTP_200_OK)
        
